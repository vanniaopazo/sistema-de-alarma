package com.example.sistemaalarma;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private TextView textUsuario;
    private TextView textEstadoSistema;
    private TextView textGas;
    private TextView textLlama;
    private TextView textVentilacion;
    private TextView textConexion;

    private Button btnActualizar;
    private Button btnSimular;
    private Button btnActivar;
    private Button btnDesactivar;
    private Button btnCerrarSesion;

    private boolean ventilacionActiva = false;

    private int gasActual = 850;
    private boolean llamaActual = false;

    private final int UMBRAL_GAS = 2000;

    private final Random random = new Random();

    private static final String RASPBERRY_URL =
            "http://10.227.83.130:8000";

    private final ExecutorService executorService =
            Executors.newSingleThreadExecutor();

    private final Handler handler =
            new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textUsuario = findViewById(R.id.textUsuario);
        textEstadoSistema = findViewById(R.id.textEstadoSistema);
        textGas = findViewById(R.id.textGas);
        textLlama = findViewById(R.id.textLlama);
        textVentilacion = findViewById(R.id.textVentilacion);
        textConexion = findViewById(R.id.textConexion);

        btnActualizar = findViewById(R.id.btnActualizar);
        btnSimular = findViewById(R.id.btnSimular);
        btnActivar = findViewById(R.id.btnActivar);
        btnDesactivar = findViewById(R.id.btnDesactivar);
        btnCerrarSesion = findViewById(R.id.btnCerrarSesion);

        String rutUsuario =
                getIntent().getStringExtra("rutUsuario");

        if (rutUsuario != null) {
            textUsuario.setText("Usuario: " + rutUsuario);
        }

        actualizarInterfaz();

        // ACTUALIZAR DATOS DESDE RASPBERRY
        btnActualizar.setOnClickListener(v -> {
            conectarRaspberry();
        });

        // SIMULAR ALERTA
        btnSimular.setOnClickListener(v -> {

            gasActual = 2500;
            llamaActual = true;

            actualizarInterfaz();

            Toast.makeText(
                    MainActivity.this,
                    "Alerta IoT simulada",
                    Toast.LENGTH_SHORT
            ).show();
        });

        // ACTIVAR VENTILACIÓN
        btnActivar.setOnClickListener(v -> {

            ventilacionActiva = true;

            actualizarInterfaz();

            Toast.makeText(
                    MainActivity.this,
                    "Ventilación activada",
                    Toast.LENGTH_SHORT
            ).show();
        });

        // DESACTIVAR VENTILACIÓN
        btnDesactivar.setOnClickListener(v -> {

            ventilacionActiva = false;

            actualizarInterfaz();

            Toast.makeText(
                    MainActivity.this,
                    "Ventilación desactivada",
                    Toast.LENGTH_SHORT
            ).show();
        });

        // CERRAR SESIÓN
        btnCerrarSesion.setOnClickListener(v -> {

            Intent intent = new Intent(
                    MainActivity.this,
                    LoginActivity.class
            );

            intent.setFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK |
                            Intent.FLAG_ACTIVITY_CLEAR_TASK
            );

            startActivity(intent);
        });
    }

    /**
     * Obtiene los datos reales desde la Raspberry.
     */
    private void conectarRaspberry() {

        textConexion.setText(
                "Conexión IoT: CONECTANDO..."
        );

        executorService.execute(() -> {

            HttpURLConnection conexion = null;

            try {

                URL url = new URL(RASPBERRY_URL);

                conexion =
                        (HttpURLConnection) url.openConnection();

                conexion.setRequestMethod("GET");
                conexion.setConnectTimeout(5000);
                conexion.setReadTimeout(5000);

                int codigoRespuesta =
                        conexion.getResponseCode();

                if (codigoRespuesta ==
                        HttpURLConnection.HTTP_OK) {

                    BufferedReader reader =
                            new BufferedReader(
                                    new InputStreamReader(
                                            conexion.getInputStream()
                                    )
                            );

                    StringBuilder respuesta =
                            new StringBuilder();

                    String linea;

                    while ((linea = reader.readLine()) != null) {
                        respuesta.append(linea);
                        respuesta.append("\n");
                    }

                    reader.close();

                    String datos =
                            respuesta.toString();

                    // Procesar datos recibidos
                    procesarDatosRaspberry(datos);

                } else {

                    handler.post(() -> {

                        textConexion.setText(
                                "Conexión IoT: ERROR HTTP"
                        );

                        Toast.makeText(
                                MainActivity.this,
                                "Error HTTP: " +
                                        codigoRespuesta,
                                Toast.LENGTH_SHORT
                        ).show();
                    });
                }

            } catch (Exception e) {

                handler.post(() -> {

                    textConexion.setText(
                            "Conexión IoT: SIN CONEXIÓN"
                    );

                    Toast.makeText(
                            MainActivity.this,
                            "No se pudo conectar a la Raspberry",
                            Toast.LENGTH_SHORT
                    ).show();
                });

            } finally {

                if (conexion != null) {
                    conexion.disconnect();
                }
            }
        });
    }

    /**
     * Procesa:
     *
     * Gas: 850
     * Llama: false
     * Ventilación: false
     */
    private void procesarDatosRaspberry(String datos) {

        try {

            String[] lineas =
                    datos.trim().split("\\n");

            for (String linea : lineas) {

                linea = linea.trim();

                if (linea.startsWith("Gas:")) {

                    String valor =
                            linea.substring(4).trim();

                    gasActual =
                            Integer.parseInt(valor);
                }

                else if (linea.startsWith("Llama:")) {

                    String valor =
                            linea.substring(6).trim();

                    llamaActual =
                            Boolean.parseBoolean(valor);
                }

                else if (linea.startsWith("Ventilación:")) {

                    String valor =
                            linea.substring(12).trim();

                    ventilacionActiva =
                            Boolean.parseBoolean(valor);
                }
            }

            handler.post(() -> {

                actualizarInterfaz();

                textConexion.setText(
                        "Conexión IoT: RASPBERRY CONECTADA"
                );

                Toast.makeText(
                        MainActivity.this,
                        "Datos actualizados desde Raspberry",
                        Toast.LENGTH_SHORT
                ).show();
            });

        } catch (Exception e) {

            handler.post(() -> {

                Toast.makeText(
                        MainActivity.this,
                        "Error al procesar los datos",
                        Toast.LENGTH_SHORT
                ).show();
            });
        }
    }

    private void actualizarInterfaz() {

        textGas.setText(
                "Gas / Humo: " + gasActual
        );

        if (llamaActual) {

            textLlama.setText(
                    "🔥 LLAMA DETECTADA"
            );

        } else {

            textLlama.setText(
                    "Llama: NO DETECTADA"
            );
        }

        if (gasActual > UMBRAL_GAS ||
                llamaActual) {

            textEstadoSistema.setText(
                    "🔴 ALERTA DETECTADA"
            );

            textEstadoSistema.setTextColor(
                    getResources().getColor(
                            android.R.color.holo_red_dark
                    )
            );

        } else {

            textEstadoSistema.setText(
                    "🟢 SISTEMA NORMAL"
            );

            textEstadoSistema.setTextColor(
                    getResources().getColor(
                            android.R.color.holo_green_dark
                    )
            );
        }

        if (ventilacionActiva) {

            textVentilacion.setText(
                    "Ventilación: ENCENDIDA"
            );

        } else {

            textVentilacion.setText(
                    "Ventilación: APAGADA"
            );
        }
    }

    @Override
    protected void onDestroy() {

        super.onDestroy();

        executorService.shutdown();
    }
}